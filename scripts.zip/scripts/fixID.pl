#!/usr/bin/env perl
use strict;
use warnings;

my $file = shift;
open(my $in, $file) or die;
my $h = <$in>;
print $h;
while(<$in>){
  chomp $_;
  my @line = split(/\t/,$_);
  $line[0] =~ s/_\d+$//go;
  print join("\t",@line),"\n";
}
close $in;
exit;
