#!/usr/bin/env perl
use strict;
use warnings; 

my $desc = shift;
my $table = shift;
open(my $din,$desc) or die "Can't open $desc: $!\n";
my $dHead = <$din>;
chomp $dHead;
my %map;
while(<$din>){
  chomp $_;
  my ($g) = split(/\t/,$_);
  $g =~ s/-/_/g;
  $map{$g} = $_;
}
close $din;

open(my $tin, $table) or die "Can't open $table: $!\n";
my $h = <$tin>;
chomp $h;
my ($tmp, @head) = split(/\t/,$h);
print join("\t",$dHead,@head),"\n";
while(<$tin>){
  chomp $_;
  my ($g, @line) = split(/\t/,$_);
  die "$g not found\n" if(not defined $map{$g});
  print join("\t",$map{$g},@line),"\n";
}
close $tin;
exit;

