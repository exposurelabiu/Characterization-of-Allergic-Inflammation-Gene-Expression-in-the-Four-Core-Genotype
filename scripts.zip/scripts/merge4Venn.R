#!/usr/bin/env R
args <- commandArgs(TRUE)
keeps <- c("log2FoldChange", "pvalue","padj")
for (fn in args) {
  df <- read.table(file = fn, header = TRUE, row.names=1, sep="\t")
  bn <- basename(fn)
  pre <- gsub(".DESeq2_Results.*tsv","",bn)
  df <- df[keeps]
  df$Sig <- rownames(df)
  df$Sig[df$padj >= 0.05] <- 0
  df$Sig[is.na(df$padj)] <- 0
  colnames(df) <- paste(pre, colnames(df), sep = "_")
  if(exists("dfFinal")){
    dfFinal <- merge(dfFinal, df, by=0, all=T)
    rownames(dfFinal) <- dfFinal$Row.names
    dfFinal$Row.names <- NULL
  }else{
    dfFinal <- df
  }
}

write.table(data.frame(GeneID=rownames(dfFinal),dfFinal),file="mergedDeseqResults.venn.tsv", quote=FALSE, sep="\t", na="NA", row.names=FALSE)
