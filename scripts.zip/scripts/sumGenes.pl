#!/usr/bin/env perl
use strict;
use warnings;
my $file = shift;
open(my $in, $file) or die "Can't open $file: $!\n";
my $h = <$in>;
chomp $h;
my ($id,@order) = split(/\t/,$h);
my %cnt;
while(<$in>){
  chomp $_;
  my ($g,@line) = split(/\t/,$_);
  for(my $i=0;$i<scalar @line; $i++){
    $cnt{$g}{$order[$i]}+= $line[$i];
  }
}
close $in;
print "geneID";
foreach my $s (@order){
  print "\t$s";
}
print "\n";
foreach my $g (sort keys %cnt){
  print $g;
  foreach my $s (@order){
    if(defined $cnt{$g}{$s}){
      print "\t$cnt{$g}{$s}";
    }else{
      print "\t0";
    }
  }
  print "\n";
}
exit;
