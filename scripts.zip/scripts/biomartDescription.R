library(biomaRt)
args <- c("geneNames4Biomart.tsv")
res <- read.table(file=args[1], sep="\t",header=TRUE)

ensembl <- useEnsembl(biomart = 'genes',dataset = 'mmusculus_gene_ensembl')
attributes <- listAttributes(ensembl)
bm <- getBM(attributes=c("ensembl_gene_id","mgi_id","mgi_symbol","mgi_description"),mart=ensembl)
bm$mgi_symbol <- toupper(bm$mgi_symbol)
bm2 <- getBM(attributes=c("ensembl_gene_id","entrezgene_id"),mart=ensembl)
fin <- merge(bm, bm2, by.x="ensembl_gene_id", by.y="ensembl_gene_id",all.x=TRUE, all.y=TRUE)
idx <- match( res$Genes, fin$mgi_symbol )
resFin <- data.frame(Genes=res$Genes, MGI_ID=fin$mgi_id[ idx ], Description=fin$mgi_description[ idx ], ensembl_gene_id=fin$ensembl_gene_id[idx], entrezgene_id=fin$entrezgene_id[idx])

write.table(resFin, file="geneDescriptions.tsv", quote=FALSE, sep="\t", row.names=FALSE)
