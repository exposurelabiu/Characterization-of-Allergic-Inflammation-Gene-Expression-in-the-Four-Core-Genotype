#!/usr/bin/env R
library('DESeq2')
library( "gplots" )
library("ggplot2")
library(ggrepel)
library("RColorBrewer")
library("BiocParallel")
library(pheatmap)
register(MulticoreParam(32))

args <- commandArgs(TRUE)
#args <- c("geneCounts.tsv.sum","phenoData","comparisons.new")
cat("Loading DESeq2 data\n")
counts <- read.table( file = args[1], header = TRUE, row.names=1 )
phenoData <- read.table( file = args[2], header=TRUE, sep="\t", stringsAsFactors=TRUE,)
rownames(phenoData) <- phenoData$sample
phenoData.orig <- phenoData
comps <- read.table( file = args[3], header=TRUE, stringsAsFactors=TRUE)
colnames(comps) <- c("comparison")
dds <- DESeqDataSetFromMatrix( countData = counts, colData = phenoData.orig, design = ~ treatment + chromosome + organ)
dds <- collapseReplicates(dds,dds$individual)
dds <- DESeq(dds, parallel=TRUE)
phenoData <- data.frame(sample=dds$sample,individual=dds$individual,condition=dds$condition,treatment=dds$treatment,chromosome=dds$chromosome,organ=dds$organ,stringsAsFactors=TRUE)
phenoData$condition <- factor(phenoData$condition,levels=c("PBS.XXF","PBS.XXM","PBS.XYF","PBS.XYM","HDM.XXF","HDM.XXM","HDM.XYF","HDM.XYM"))
phenoData <- phenoData[order(phenoData$chromosome),]
dds <- dds[,as.character(phenoData$individual)]
cat("Calculating rlog and vst\n")
rld <- rlog( dds )
vsd <- varianceStabilizingTransformation(dds)
rlogMat <- assay(rld)
vstMat <- assay(vsd)
cat("finding top variable genes\n")
topVarGenes <- head( order( genefilter::rowVars( rlogMat ), decreasing=TRUE ), 35 )
pdf("qcPlots.sameForAllComparisons.newComps.pdf")
    cat("plotting Dispersion Estimates\n")
    plotDispEsts( dds, ylim = c(1e-6, 1e1) )
    par( mfrow = c( 1, 3 ) )
    cat("plotting log2\n")
    plot( log2( 1+counts(dds, normalized=TRUE)[, 1:2] ), col="#00000020", pch=20, cex=0.3, main="Log2" )
    cat("plotting rlog\n")
    plot( rlogMat[, 1:2], col="#00000020", pch=20, cex=0.3, main="RLog" )
    plot( vstMat[, 1:2], col="#00000020", pch=20, cex=0.3, main="VST" )
    par( mfrow = c( 1, 1 ) )
    cat("Calculating Distance Matrix\n")
    sampleDists <- dist( t( rlogMat ) )
    sampleDistMatrix <- as.matrix( sampleDists )
    rownames(sampleDistMatrix) <- paste(gsub("Sample_","",rld$individual),":",rld$condition,sep="")
    colnames(sampleDistMatrix) <- paste(gsub("Sample_","",rld$individual),":",rld$condition,sep="")
    cat("Plotting sample vs sample heatmap\n")
    ph <- pheatmap(sampleDistMatrix, color = greenred(256), border_color = NA, main="Sample vs Sample", fontsize_row=6, fontsize_col=6, show_rownames=TRUE, cluster_cols=TRUE, scale="none")
    cat("Plotting PCA\n")
    data <- plotPCA(rld, intgroup=c("condition", "sample", "individual","treatment","chromosome","organ"), returnData=TRUE)
    percentVar <- round(100 * attr(data, "percentVar"))
    print(ggplot(data, aes(PC1, PC2, color=condition, label=individual)) + geom_text_repel(max.overlaps = 14, box.padding = 0.5, min.segment.length = 0, size=2) +
            geom_point(size=3) + ggtitle("PC1 vs PC2") + xlab(paste0("PC1: ",percentVar[1],"% variance")) + ylab(paste0("PC2: ",percentVar[2],"% variance")) +
            theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) )
    shapes <- as.integer(unique(phenoData$chromosome))
    if(length(shapes) > 6){
      print(ggplot(data, aes(PC1, PC2, shape=chromosome, color=treatment)) + scale_shape_manual(values=shapes) + geom_point(size=3) + ggtitle("PC1 vs PC2") + xlab(paste0("PC1: ",percentVar[1],"% variance")) + ylab(paste0("PC2: ",percentVar[2],"% variance")) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.border = element_rect(colour = "black", fill=NA, size=.5),legend.title = element_blank(), legend.box.background = element_rect(size = 0.5, colour = "black")) )
      print(ggplot(data, aes(PC1, PC2, shape=chromosome, color=treatment, label=individual)) + geom_text_repel(max.overlaps = 14, box.padding = 0.5, min.segment.length = 0, size=2) +
            scale_shape_manual(values=shapes) + geom_point(size=3) + ggtitle("PC1 vs PC2") + xlab(paste0("PC1: ",percentVar[1],"% variance")) + ylab(paste0("PC2: ",percentVar[2],"% variance")) +
            theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.border = element_rect(colour = "black", fill=NA, size=.5),legend.title = element_blank(), legend.box.background = element_rect(size = 0.5, colour = "black")) )
    } else {
      print(ggplot(data, aes(PC1, PC2, shape=chromosome, color=treatment)) + geom_point(size=3) + ggtitle("PC1 vs PC2") + xlab(paste0("PC1: ",percentVar[1],"% variance")) + ylab(paste0("PC2: ",percentVar[2],"% variance")) + 
            theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.border = element_rect(colour = "black", fill=NA, size=.5)) )
      print(ggplot(data, aes(PC1, PC2, shape=chromosome, color=treatment, label=individual)) + geom_text_repel(max.overlaps = 14, box.padding = 0.5, min.segment.length = 0, size=2) +
            geom_point(size=3) + ggtitle("PC1 vs PC2") + xlab(paste0("PC1: ",percentVar[1],"% variance")) + ylab(paste0("PC2: ",percentVar[2],"% variance")) +
            theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.border = element_rect(colour = "black", fill=NA, size=.5)) )
      print(ggplot(data, aes(PC1, PC2, shape=chromosome, color=organ)) + geom_point(size=3) + ggtitle("PC1 vs PC2") + xlab(paste0("PC1: ",percentVar[1],"% variance")) + ylab(paste0("PC2: ",percentVar[2],"% variance")) + 
            theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.border = element_rect(colour = "black", fill=NA, size=.5)) )
      print(ggplot(data, aes(PC1, PC2, shape=chromosome, color=organ, label=individual)) + geom_text_repel(max.overlaps = 14, box.padding = 0.5, min.segment.length = 0, size=2) +
            geom_point(size=3) + ggtitle("PC1 vs PC2") + xlab(paste0("PC1: ",percentVar[1],"% variance")) + ylab(paste0("PC2: ",percentVar[2],"% variance")) +
            theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.border = element_rect(colour = "black", fill=NA, size=.5)) )
      print(ggplot(data, aes(PC1, PC2, shape=treatment, color=organ)) + geom_point(size=3) + ggtitle("PC1 vs PC2") + xlab(paste0("PC1: ",percentVar[1],"% variance")) + ylab(paste0("PC2: ",percentVar[2],"% variance")) + 
            theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.border = element_rect(colour = "black", fill=NA, size=.5)) )
      print(ggplot(data, aes(PC1, PC2, shape=treatment, color=organ, label=individual)) + geom_text_repel(max.overlaps = 14, box.padding = 0.5, min.segment.length = 0, size=2) +
            geom_point(size=3) + ggtitle("PC1 vs PC2") + xlab(paste0("PC1: ",percentVar[1],"% variance")) + ylab(paste0("PC2: ",percentVar[2],"% variance")) +
            theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.border = element_rect(colour = "black", fill=NA, size=.5)) )
    }
dev.off()

cat("Creating DESeq matrix and running main function\n")
for (comp in unique(comps$comparison)){
  tc <- strsplit(comp,",")[[1]]
  cond2 <- tc[1]
  control <- tc[2]
  cat("Starting Analyis ", cond2, "_vs_", control, "\n")
  outname <- paste(cond2, "_vs_", control, sep="")

  pdf(paste(outname, ".deseq2.pdf", sep=""))
  cat("Calculating fold-change\n")
  res <- results( dds, contrast = c("chromosome", cond2, control), parallel=TRUE )
  
  select <- order(res$padj)
  filter <- na.pass(res$padj < 0.05 & abs(res$log2FoldChange) > 1)
  filter <- filter %in% TRUE
  sigResults <- na.omit(res[ na.omit(res$padj) < .05, ])
  write.table(as.data.frame(res)[select,], file=paste(outname,".DESeq2_Results.tsv", sep=""), quote=FALSE, sep="\t", na="NA", col.names=NA)
  resC <- merge(res, counts(dds, normalized=TRUE), by=0, all=T)
  rownames(resC) <- resC$Row.names
  resC <- resC[,-1]
  selectC <- order(resC$padj)
  write.table(as.data.frame(resC)[selectC,], file=paste(outname,".DESeq2_Results.withCounts.tsv", sep=""), quote=FALSE, sep="\t", na="NA", col.names=NA)
  
  # create bins using the quantile function
  cat("create bins using the quantile function\n")
  qs <- c( 0, quantile( res$baseMean[res$baseMean > 0], 0:7/7 ) )
  # "cut" the genes into the bins
  bins <- cut( res$baseMean, qs )
  # rename the levels of the bins using the middle point
  levels(bins) <- paste0("~",round(.5*qs[-1] + .5*qs[-length(qs)]))
  # calculate the ratio of $p$ values less than .01 for each bin
  ratios <- tapply( res$pvalue, bins, function(p) mean( p < .01, na.rm=TRUE ) )
  # plot these ratios
  cat("plotting ratio barplot\n")
  barplot(ratios, xlab="mean normalized count", ylab="ratio of small $p$ values")
  cat("plotting basemean quantiles\n")
  plot(metadata(res)$filterNumRej,type="b", ylab="number of rejections", xlab="quantiles of filter")
  lines(metadata(res)$lo.fit, col="red")
  abline(v=metadata(res)$filterTheta)
 
  cat("Creating MAplot\n")
  hist( res$pvalue, breaks=20, col="grey" )
  plotMA( res, ylim = c(-1, 1), alpha=0.05)
  cat("Creating volcano plot\n")
  resdata <- merge(as.data.frame(res), as.data.frame(counts(dds, normalized=TRUE)), by="row.names", sort=FALSE)
  resdata <- resdata[! is.na(resdata$padj),]
  names(resdata)[1] <- "Gene"
  max <- max(resdata$log2FoldChange)
  maxbreak <- round(max)
  if(-1*max > min(resdata$log2FoldChange)){
    max <- -1 * min(resdata$log2FoldChange)
    maxbreak <- round(-1 * min(resdata$log2FoldChange))
  }
  resdata$threshold[abs(resdata$log2FoldChange) > 1] <- "|LogFC| > 1"
  resdata$threshold[resdata$padj < 0.05] <- "FDR < 0.05"
  resdata$threshold[abs(resdata$log2FoldChange) > 1 & resdata$padj < 0.05] <- "|LogFC| > 1 & FDR < 0.05"
  resdata$threshold[is.na(resdata$threshold)] <- "Not Significant"
  resdata$threshold <- factor(resdata$threshold,levels=c("|LogFC| > 1 & FDR < 0.05","FDR < 0.05","|LogFC| > 1","Not Significant"))
  resdata$label <- NA
  resdata$label[abs(resdata$log2FoldChange) > 1 & resdata$padj < 0.05] <- resdata$Gene[abs(resdata$log2FoldChange) > 1 & resdata$padj < 0.05]
  resdata$label <- gsub("_\\d+$","",resdata$label)
  print(ggplot(data=resdata, aes(x=log2FoldChange, y=-log10(padj), colour=threshold, label=label)) +
        geom_point(size=1.75) + geom_text_repel(max.overlaps = 14, box.padding = 0.5, min.segment.length = 0, size=2) +
        geom_hline(yintercept = -log10(.05), linetype="dashed") + geom_vline(xintercept = 1, linetype="dashed") + geom_vline(xintercept = -1, linetype="dashed") +
        xlab("log2 fold change") + ylab("-log10 fdr") + labs(title=gsub("_"," ",outname)) + #xlim(-1*max,max) +
        scale_x_continuous(limits=c(-1*max,max), breaks=seq(-1*maxbreak, maxbreak, 1 )) +
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.border = element_rect(colour = "black", fill=NA, size=.5),legend.key=element_rect(fill="transparent",colour=NA),legend.title = element_blank(), plot.title = element_text(hjust = 0.5)) +
        guides(color = guide_legend(override.aes = list(size = 3))))

  print(ggplot(data=resdata, aes(x=log2FoldChange, y=-log10(padj), colour=threshold, label=label)) +
        geom_point(size=1.75) + geom_text_repel(max.overlaps = 14, box.padding = 0.5, min.segment.length = 0, size=2) +
        geom_hline(yintercept = -log10(.05), linetype="dashed") + geom_vline(xintercept = 1, linetype="dashed") + geom_vline(xintercept = -1, linetype="dashed") +
        xlab("log2 fold change") + ylab("-log10 fdr") + labs(title=gsub("_"," ",outname)) + #xlim(-1*max,max) +
        theme_classic() +
        scale_x_continuous(limits=c(-1*max,max), breaks=seq(-1*maxbreak, maxbreak, 1 )) +
        theme(plot.title = element_text(hjust = 0.5),legend.title = element_blank()) +
        guides(color = guide_legend(override.aes = list(size = 3))))

  cat("plotting heatmaps\n")
  subPheno <- phenoData[phenoData$chromosome==cond2 | phenoData$chromosome==control,]
  subRlogMat <- rlogMat[,as.character(subPheno$individual)]
  select <- order(res$padj)
  rlogPlot <- rlogMat[select,]
  mat <- rlogMat[select[1:50],]
  mat <- mat - rowMeans(mat)
  colnames(mat) <- phenoData$individual
  df <- data.frame(SampleType=phenoData$chromosome)
  rownames(df) <- colnames(mat)
  mycols <- brewer.pal(8, "Dark2")[1:length(unique(phenoData$chromosome))]
  ann_colors <- list(SampleType=c(mycols))
  names(ann_colors$SampleType) <- unique(phenoData$chromosome)
  rownames(mat) <- gsub("_\\d+$","",rownames(mat))  
  title <- "Top 50 Significant Heatmap"
  if(nrow(mat) > 2){
    ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = df, annotation_colors = ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=FALSE, cluster_cols=FALSE, scale="row")
    ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = df, annotation_colors = ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=TRUE, cluster_cols=FALSE, scale="row")
    genes <- data.frame(gene=rownames(mat[ph$tree_row[["order"]],]))
    write.table(genes, file=paste(outname,".top50HeatmapGeneOrder.tsv",sep=""),sep="\t", quote=FALSE, row.names=FALSE)
  }
  cat("1.5 sub heatmap\n")
  mat <- subRlogMat[select[1:50],]
  mat <- mat - rowMeans(mat)
  dfSub2 <- data.frame(SampleType=gsub("_"," ",subPheno$chromosome))
  rownames(dfSub2) <- colnames(mat)
  sub_ann_colors <- list(SampleType=ann_colors$SampleType[unique(dfSub2$SampleType)])
  if(nrow(mat) > 2){
    ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = dfSub2, annotation_colors = sub_ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=FALSE, cluster_cols=FALSE, scale="row")
    ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = dfSub2, annotation_colors = sub_ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=TRUE, cluster_cols=FALSE, scale="row")
  }

  mat <- rlogMat[filter,]
  if( !is.null(nrow(mat)) && nrow(mat) > 2){
    mat <- mat - rowMeans(mat)
    colnames(mat) <- phenoData$individual
    df <- data.frame(SampleType=phenoData$chromosome)
    rownames(df) <- colnames(mat)
    rownames(mat) <- gsub("_\\d+$","",rownames(mat))  
    title <- "FDR < 0.05 and FC > 2 Heatmap"
    if( !is.null(nrow(mat)) && nrow(mat) > 2){
      ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = df, annotation_colors = ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=FALSE, cluster_cols=FALSE, scale="row")
      ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = df, annotation_colors = ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=TRUE, cluster_cols=FALSE, scale="row")
      genes <- data.frame(gene=rownames(mat[ph$tree_row[["order"]],]))
      write.table(genes, file=paste(outname,".FCgreater2SignficantHeatmapGeneOrder.tsv",sep=""),sep="\t", quote=FALSE, row.names=FALSE)
    }
    mat <- subRlogMat[filter,]
    mat <- mat - rowMeans(mat)

    if(nrow(mat) > 2){
      ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = dfSub2, annotation_colors = sub_ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=FALSE, cluster_cols=FALSE, scale="row")
      ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = dfSub2, annotation_colors = sub_ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=TRUE, cluster_cols=FALSE, scale="row")
    }
  }

  mat <- rlogMat[ topVarGenes, ]
  mat <- mat - rowMeans(mat)
  colnames(mat) <- phenoData$individual
  df <- data.frame(SampleType=phenoData$chromosome)
  rownames(df) <- colnames(mat)
  rownames(mat) <- gsub("_\\d+$","",rownames(mat))  
  title <- "Top Variable Genes Heatmap"
  if( !is.null(nrow(mat)) && nrow(mat) > 2){
    ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = df, annotation_colors = ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=FALSE, cluster_cols=FALSE, scale="row")
    ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = df, annotation_colors = ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=TRUE, cluster_cols=FALSE, scale="row")
  }
  cat("sub heatmap\n")
  mat <- subRlogMat[topVarGenes,]
  if( !is.null(nrow(mat)) && nrow(mat) > 2){
    mat <- mat - rowMeans(mat)
    colnames(mat) <- paste(subPheno$chromosome, " ", subPheno$sample, sep="")
    colnames(mat) <- subPheno$sample
    if( !is.null(nrow(mat)) && nrow(mat) > 2){
      ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = dfSub2, annotation_colors = sub_ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=FALSE, cluster_cols=FALSE, scale="row")
      ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = dfSub2, annotation_colors = sub_ann_colors, border_color = NA, main=title, fontsize_row=4, fontsize_col=6, show_rownames=TRUE, cluster_cols=FALSE, scale="row")
    }
  }
  dev.off()
  cat(outname, " output complete\n")
  desc <- data.frame(column=rownames(mcols(res)), description=mcols(res)$description)
  write.table(desc, file="column_descriptions.txt", sep="\t", quote=FALSE, row.names=FALSE)
  save.image(paste(outname, ".DESeq2.RData", sep=""))
  writeLines(capture.output(sessionInfo()), paste(outname,".sessionInfo.deseq2.txt", sep=""))
}
